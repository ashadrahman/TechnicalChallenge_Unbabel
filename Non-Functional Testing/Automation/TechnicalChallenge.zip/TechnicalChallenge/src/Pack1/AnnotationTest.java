package Pack1;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class AnnotationTest {
	
	WebDriver driver;
	@BeforeClass
	public void LoginTest()
	{	
		try
		{
			System.setProperty("webdriver.chrome.driver","F:\\Sanjay\\Selenium\\SeleniumFile\\chromedriver.exe");
			driver  =new ChromeDriver();
			driver.get("https://staging.annotation.tools.unbabel.com/");
			driver.findElement(By.xpath("//a[@href='/login/']")).click();
			driver.findElement(By.xpath("//input[@id='username']")).sendKeys("emanuel+ashad@unbabel.com");
			driver.findElement(By.xpath("//input[@id='password']")).sendKeys("Pune@2018");
			driver.findElement(By.xpath("//button[@type='submit']")).click();
			
			String ExpectedText="Welcome to Unbabel's Annotation Tool.";
			String ActualText=driver.findElement(By.xpath("//div[contains(text(),\"Welcome to Unbabel's Annotation Tool\")]")).getText();
			if(ActualText.contains(ExpectedText))
			{
			  System.out.println("Successfully logged in");
			}
			else
			{
				System.out.println("Not able to login");
			}
		}
			catch(Exception e)
			{
				e.printStackTrace();
			}
	}
		
	@Test
	public void SelectTextTest() throws InterruptedException
	{
		try{
			
			driver.findElement(By.linkText("ES to EN")).click();
			Thread.sleep(4000);
			driver.findElement(By.xpath("//div[@class='c-TopBar__middle']/div/div/div[4]/span")).click();	
			Thread.sleep(4000);
			WebElement element=driver.findElement(By.xpath("//p[contains(text(),'We will not save')]"));	
		    Actions action = new Actions(driver);
			action.moveToElement(element,100,0).click().keyDown(Keys.SHIFT).moveToElement(element,200,0).click().keyUp(Keys.SHIFT).build().perform();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	
	@Test(dependsOnMethods={"SelectTextTest"})
	public void PerformAnnotationTest() throws InterruptedException
	{
	  try{
		driver.findElement(By.xpath("//span[contains(text(),'Accuracy')]")).click();
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[contains(text(),'Mistranslation')]")).click();	
		Thread.sleep(1000);
		driver.findElement(By.xpath("//span[contains(text(),'Ambiguous Translation')]")).click();
		
		driver.findElement(By.id("majorSeverity")).click();
		driver.findElement(By.xpath("//button[contains(text(),'Add')]")).click();
	  }
	  catch(Exception e)
	  {
		  e.printStackTrace();
	  }
	}
	
	@Test(dependsOnMethods={"SelectTextTest","PerformAnnotationTest"})
	public void FinishAnnotationTest() throws InterruptedException
	{
	 try{
			driver.findElement(By.xpath("//div[contains(text(),'Finish or Report')]")).click();
			Thread.sleep(6000);
			
			//driver.findElement(By.xpath("//div/*[@class='c-StarGroup__star'][3]")).click();
			driver.findElement(By.xpath("//textarea[@name='comment']")).sendKeys("success");
		    driver.findElement(By.xpath("//button[contains(text(),'Finish')]")).click();
		    Thread.sleep(1000);
		    
		    driver.findElement(By.xpath("//button[contains(text(),'Yes')]")).click();
	 }
		catch(Exception e)
		{
			e.printStackTrace();		
		}
	}
	
}
